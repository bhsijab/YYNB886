# 秧秧 ColorOS 背景管理器 / LSPosed Helper

这是配套的 Android Studio 工程：同一个 APK 同时承担：
1. LSPosed/Xposed Hook：在 `com.android.settings` 中替换 ColorOS/OxygenOS 关于本机顶部版本卡片。
2. 管理界面：选择图片、选择视频、恢复默认、重启设置。

## Hook 目标
- `com.oplus.settings.widget.preference.AboutDeviceOtaUpdatePreference`
- `about_device_top_bg`

## LSPosed 设置
安装 APK 后，在 LSPosed 中启用本模块，并将作用域限制为：
`com.android.settings`

## 构建

```bash
gradle :app:assembleDebug --no-daemon
```

需要 Android SDK 36 与 Java 17。

项目带 GitHub Actions，可在 Ubuntu runner 上直接构建 Debug APK。
