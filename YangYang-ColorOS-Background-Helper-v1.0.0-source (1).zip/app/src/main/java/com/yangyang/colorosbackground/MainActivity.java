package com.yangyang.colorosbackground;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_IMAGE = 11;
    private static final int REQ_VIDEO = 12;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        String action = getIntent().getStringExtra("action");
        if ("image".equals(action)) pickImage();
        else if ("video".equals(action)) pickVideo();
        else if ("restore".equals(action)) restoreAsync();
    }

    private void buildUi() {
        int pad = dp(20);
        ScrollView sc = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(18), pad, pad);
        root.setBackgroundColor(Color.rgb(247,246,251));

        TextView title = new TextView(this);
        title.setText("秧秧 ColorOS 背景管理器");
        title.setTextSize(27); title.setTextColor(Color.rgb(25,25,29)); title.setTypeface(null, 1);
        root.addView(title, lp(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("选择图片或视频，应用到设置 → 关于本机顶部版本卡片。");
        sub.setTextSize(14); sub.setTextColor(Color.rgb(117,116,124)); sub.setPadding(0, dp(7),0,dp(12));
        root.addView(sub, lp(-1,-2));

        status = new TextView(this);
        status.setText("状态：等待操作"); status.setTextSize(14); status.setTextColor(Color.rgb(57,126,95));
        root.addView(status, lp(-1,-2));

        root.addView(button("🖼 自定义图片", v -> pickImage()), lp(-1, dp(52)));
        root.addView(button("🎞 自定义视频", v -> pickVideo()), lp(-1, dp(52)));
        root.addView(button("↩ 恢复系统默认", v -> restoreAsync()), lp(-1, dp(52)));
        root.addView(button("⚙ 重启设置应用", v -> restartSettings()), lp(-1, dp(52)));

        TextView info = new TextView(this);
        info.setText("LSPosed：请将本应用作用域设置为 com.android.settings。\n\n图片：PNG / JPG / WEBP\n视频：MP4 / WebM，循环播放\n\n媒体保存目录：/sdcard/.yangyang_coloros/");
        info.setTextSize(13); info.setTextColor(Color.rgb(117,116,124)); info.setPadding(dp(2),dp(18),dp(2),0);
        root.addView(info, lp(-1,-2));
        sc.addView(root); setContentView(sc);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this); b.setText(text); b.setTextSize(15); b.setAllCaps(false); b.setOnClickListener(l); return b;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w,h); p.bottomMargin=dp(10); return p; }
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }

    private void pickImage() { pick("image/*", REQ_IMAGE); }
    private void pickVideo() { pick("video/*", REQ_VIDEO); }
    private void pick(String type, int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(type); startActivityForResult(i, req);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data); if(result!=RESULT_OK || data==null || data.getData()==null) return;
        final Uri uri=data.getData();
        io.execute(() -> {
            try {
                File cache = new File(getCacheDir(), "selected.media");
                try(InputStream in=getContentResolver().openInputStream(uri); FileOutputStream out=new FileOutputStream(cache)) {
                    byte[] buf=new byte[1024*1024]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
                }
                String ext = req==REQ_VIDEO ? "mp4" : "png";
                String dst = "/sdcard/.yangyang_coloros/settings_ota_card."+ext;
                String other = req==REQ_VIDEO ? "/sdcard/.yangyang_coloros/settings_ota_card.png" : "/sdcard/.yangyang_coloros/settings_ota_card.mp4";
                String cmd = "mkdir -p /sdcard/.yangyang_coloros && rm -f '"+other+"' && cp '"+cache.getAbsolutePath()+"' '"+dst+"' && chmod 644 '"+dst+"' && echo '"+(req==REQ_VIDEO?"video":"image")+"' > /sdcard/.yangyang_coloros/mode";
                int code = su(cmd);
                runUi(() -> status.setText(code==0 ? "状态：已应用，可重启设置查看" : "状态：Root 复制失败，请确认 KernelSU 已授权"));
                cache.delete();
                if(code==0) restartSettings();
            } catch(Exception e) { runUi(() -> status.setText("状态：选择文件失败："+e.getClass().getSimpleName())); }
        });
    }

    private void restoreAsync() {
        io.execute(() -> { int code=su("rm -f /sdcard/.yangyang_coloros/settings_ota_card.png /sdcard/.yangyang_coloros/settings_ota_card.mp4 /sdcard/.yangyang_coloros/mode 2>/dev/null || true"); runUi(() -> status.setText(code==0?"状态：已恢复系统默认":"状态：恢复失败")); restartSettings(); });
    }
    private void restartSettings() { io.execute(() -> su("am force-stop com.android.settings 2>/dev/null || true")); }
    private int su(String command) {
        try { Process p=Runtime.getRuntime().exec(new String[]{"su","-c",command}); return p.waitFor(); } catch(Exception e) { return -1; }
    }
    private void runUi(Runnable r) { runOnUiThread(r); }
}
