package com.yangyang.colorosbackground;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.io.File;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class YangYangHook implements IXposedHookLoadPackage {
    private static final String SETTINGS = "com.android.settings";
    private static final String PREF_CLASS = "com.oplus.settings.widget.preference.AboutDeviceOtaUpdatePreference";
    private static final String MEDIA_DIR = "/sdcard/.yangyang_coloros";
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!SETTINGS.equals(lpparam.packageName)) return;
        try {
            Class<?> cls = XposedHelpers.findClass(PREF_CLASS, lpparam.classLoader);
            XposedBridge.hookAllMethods(cls, "onBindViewHolder", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        if (param.args.length == 0 || param.args[0] == null) return;
                        Object holder = param.args[0];
                        View item = (View) XposedHelpers.getObjectField(holder, "itemView");
                        if (item == null) return;
                        main.post(() -> apply(item));
                    } catch (Throwable t) { XposedBridge.log("[YangYangBG] hook: "+t); }
                }
            });
            XposedBridge.log("[YangYangBG] Hook installed");
        } catch (Throwable t) {
            XposedBridge.log("[YangYangBG] Unable to hook: "+t);
        }
    }

    private void apply(View item) {
        try {
            Context c = item.getContext();
            int id = c.getResources().getIdentifier("about_device_top_bg", "id", SETTINGS);
            if (id == 0) return;
            ImageView original = item.findViewById(id);
            if (original != null) original.setVisibility(View.GONE);

            File dir = new File(MEDIA_DIR);
            File image = new File(dir, "settings_ota_card.png");
            File video = new File(dir, "settings_ota_card.mp4");
            File mode = new File(dir, "mode");

            removeOldVideo(item);
            String m = "";
            if (mode.isFile()) {
                try { m = new String(java.nio.file.Files.readAllBytes(mode.toPath())).trim(); } catch (Throwable ignored) {}
            }
            if ("video".equals(m) && video.isFile()) {
                installVideo(item, video);
            } else if (image.isFile()) {
                Bitmap b = BitmapFactory.decodeFile(image.getAbsolutePath());
                if (b != null) item.setBackground(new BitmapDrawable(c.getResources(), b));
            }
        } catch (Throwable t) { XposedBridge.log("[YangYangBG] apply: "+t); }
    }

    private void installVideo(View item, File video) {
        if (!(item instanceof ViewGroup)) return;
        ViewGroup parent=(ViewGroup)item;
        Object existing=parent.getTag(R.id.yangyang_video_tag);
        if (existing instanceof TextureView) return;
        TextureView tv=new TextureView(item.getContext());
        ViewGroup.LayoutParams lp=null;
        try { lp=parent.getChildCount()>0?parent.getChildAt(0).getLayoutParams():new ViewGroup.LayoutParams(-1,-1); } catch(Throwable ignored) {}
        if(lp==null) lp=new ViewGroup.LayoutParams(-1,-1);
        try { parent.addView(tv,0,lp); } catch(Throwable t) { return; }
        parent.setTag(R.id.yangyang_video_tag,tv);
        MediaPlayer mp=new MediaPlayer();
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st,int w,int h){
                try{
                    mp.setDataSource(item.getContext(), Uri.fromFile(video));
                    mp.setSurface(new Surface(st)); mp.setLooping(true); mp.setOnPreparedListener(MediaPlayer::start); mp.prepareAsync();
                    tv.setTag(R.id.yangyang_player_tag,mp);
                }catch(Throwable t){try{mp.release();}catch(Throwable ignored){}}
            }
            public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture s,int w,int h){}
            public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture s){try{mp.stop();}catch(Throwable ignored){} try{mp.release();}catch(Throwable ignored){} return true;}
            public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture s){}
        });
    }

    private void removeOldVideo(View item){
        if(!(item instanceof ViewGroup)) return; ViewGroup p=(ViewGroup)item;
        Object o=p.getTag(R.id.yangyang_video_tag); if(o instanceof View){ p.removeView((View)o); }
        p.setTag(R.id.yangyang_video_tag,null); p.setTag(R.id.yangyang_player_tag,null);
    }
}
